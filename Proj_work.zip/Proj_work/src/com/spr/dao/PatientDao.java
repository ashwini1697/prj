package com.spr.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;

import com.spr.dto.Patient;


public interface PatientDao {
	void add(Patient patient);
	void remove(int patientId);
	void edit(Patient patient);
	Patient selectById(int patientId);
	List<Patient> selectAll();
	
	

}
