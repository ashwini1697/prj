package com.spr.serv;

import java.util.List;

import com.spr.dto.Patient;



public interface PatientServ {

	
	void add(Patient patient);
	void remove(int patientId);
	void edit(Patient patient);
	Patient selectById(int patientId);
	List<Patient> selectAll();
}
