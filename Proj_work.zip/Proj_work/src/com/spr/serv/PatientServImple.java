package com.spr.serv;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spr.dao.PatientDao;
import com.spr.dto.Patient;

@Service
public class PatientServImple implements PatientServ{

	@Autowired
	private PatientDao patientDao;
	
	@Override
	public void add(Patient patient) {
		// TODO Auto-generated method stub
		patientDao.add(patient);
	}

	@Override
	public void remove(int patientId) {
		// TODO Auto-generated method stub
		patientDao.remove(patientId);
		
	}

	@Override
	public void edit(Patient patient) {
		// TODO Auto-generated method stub
		patientDao.edit(patient);
	}

	@Override
	public Patient selectById(int patientId) {
		// TODO Auto-generated method stub
		return patientDao.selectById(patientId);
	}

	@Override
	public List<Patient> selectAll() {
		// TODO Auto-generated method stub
		return patientDao.selectAll();
	}

}
